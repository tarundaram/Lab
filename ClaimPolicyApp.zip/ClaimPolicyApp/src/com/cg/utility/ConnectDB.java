package com.cg.utility;

import java.sql.Connection;
import java.sql.DriverManager;



public class ConnectDB {
	
	String driverName="oracle.jdbc.driver.OracleDriver";
	String url="jdbc:oracle:thin:@localhost:1521:xe";
	String user="system";
	String password="oracle";
	
	public Connection getConnection() throws Exception {
		Class.forName(driverName);
		Connection con = DriverManager.getConnection(url, user, password);
		return con;
	}

}
