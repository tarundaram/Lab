package com.cg.dao;

import java.util.List;
import java.util.Map;

import com.cg.bean.Claim;
import com.cg.bean.ClaimDetails;
import com.cg.bean.Questions;
import com.cg.bean.UserRole;

public interface IPolicyClaimDao {
	public String validate(String userName,String password);
	
	public List<String> viewPolicy(String userName,String roleCode);
	
	public List<String> viewClaimStatus(String username,String roleCode);
	
	public Map<Claim,ClaimDetails> viewClaimDetail(int claimNumber);
	

	
	public boolean createUser(UserRole user);
	
	public List<String> generateReport();//link it with viewClaimdetail()
	
	public int storeClaimForm(Claim claim);
	
	public Questions getQuestions(int policyNumber);
	
	public void storeAnswers(ClaimDetails myAnswers);

	
	
}
