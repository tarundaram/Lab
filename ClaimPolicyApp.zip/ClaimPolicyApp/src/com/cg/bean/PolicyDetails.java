package com.cg.bean;

public class PolicyDetails {
private int accountNumber;
private int policyNumber;
private String questionId;
private String answer;
private String businessId;
public PolicyDetails(int accountNumber, int policyNumber, String questionId, String answer, String businessId) {
	super();
	this.accountNumber = accountNumber;
	this.policyNumber = policyNumber;
	this.questionId = questionId;
	this.answer = answer;
	this.businessId = businessId;
}
public PolicyDetails() {
	super();
}
public int getAccountNumber() {
	return accountNumber;
}
public void setAccountNumber(int accountNumber) {
	this.accountNumber = accountNumber;
}
public int getPolicyNumber() {
	return policyNumber;
}
public void setPolicyNumber(int policyNumber) {
	this.policyNumber = policyNumber;
}
public String getQuestionId() {
	return questionId;
}
public void setQuestionId(String questionId) {
	this.questionId = questionId;
}
public String getAnswer() {
	return answer;
}
public void setAnswer(String answer) {
	this.answer = answer;
}
public String getBusinessId() {
	return businessId;
}
public void setBusinessId(String businessId) {
	this.businessId = businessId;
}

}
