package com.cg.bean;

public class Accounts {
private int accountNumber;
private String userName;
public Accounts(int accountNumber, String userName) {
	super();
	this.accountNumber = accountNumber;
	this.userName = userName;
}
public Accounts() {
	super();
}
public int getAccountNumber() {
	return accountNumber;
}
public void setAccountNumber(int accountNumber) {
	this.accountNumber = accountNumber;
}
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}

}
