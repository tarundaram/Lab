 package com.cg.service;

import java.util.List;
import java.util.Map;

import com.cg.bean.Claim;
import com.cg.bean.ClaimDetails;
import com.cg.bean.Questions;
import com.cg.bean.UserRole;
import com.cg.dao.PolicyClaimDao;

public class PolicyClaimService implements IPolicyClaimService {
	
	public PolicyClaimDao dao;

	public PolicyClaimService() {
		//super();
		 dao=new PolicyClaimDao();
	}

	@Override
	public String validate(String userName, String password) {
		
		return dao.validate(userName,password);
	}

	@Override
	public List<String> viewPolicy(String userName,String roleCode) {
		
		return dao.viewPolicy(userName,roleCode);
	}

	@Override
	public List<String> viewClaimStatus(String username,String roleCode) {
		
		return dao.viewClaimStatus(username,roleCode);
	}

	@Override
	public Map<Claim,ClaimDetails> viewClaimDetail(int claimNumber) {
		
		return dao.viewClaimDetail(claimNumber);
	}

	

	@Override
	public boolean createUser(UserRole user) {
		// TODO Auto-generated method stub
		return dao.createUser(user);
	}

	@Override
	public List<String> generateReport() {
		
		return dao.generateReport();
	}

	

	@Override
	public int storeClaimForm(Claim claim) {
		
		return dao.storeClaimForm(claim);
	}

	@Override
	public Questions getQuestions(int policyNumber) {
		
		return dao.getQuestions(policyNumber);
	}

	@Override
	public void storeAnswers(ClaimDetails myAnswers) {
		dao.storeAnswers(myAnswers);
		
	}

}
